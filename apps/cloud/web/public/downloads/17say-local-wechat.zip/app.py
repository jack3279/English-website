import ctypes
import json
import os
import queue
import sqlite3
import threading
import sys
import time
import tkinter as tk
from pathlib import Path
from tkinter import ttk, messagebox
from concurrent.futures import ThreadPoolExecutor
from core import Client, Journal, send_task

DATA = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "17say-wechat-helper"
DATA.mkdir(parents=True, exist_ok=True)

class App:
    def __init__(self, root):
        self.root = root
        self.client = Client()
        self.pool = ThreadPoolExecutor(max_workers=1)
        self.events = queue.Queue()
        self.journal = None
        self.parents = []
        self.active = False
        self.tested = False
        self.busy = False
        self.last_send = 0
        try:
            self.bindings = json.loads((DATA / "bindings.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            self.bindings = {}
        root.title("17say · 本机微信课前提醒")
        root.geometry("760x740")
        root.minsize(690, 650)
        body = ttk.Frame(root, padding=18)
        body.pack(fill="both", expand=True)
        ttk.Label(body, text="本机微信课前提醒", font=("Microsoft YaHei UI", 17, "bold")).pack(anchor="w")
        ttk.Label(body, text="先登录网站 → 测试文件传输助手 → 绑定家长 → 预览任务 → 开启自动发送").pack(anchor="w", pady=(5, 12))
        login = ttk.LabelFrame(body, text="1. 网站管理员登录（密码与登录令牌不保存到电脑）", padding=10)
        login.pack(fill="x")
        self.email = tk.StringVar()
        self.password = tk.StringVar()
        ttk.Entry(login, textvariable=self.email, width=28).grid(row=0, column=0, padx=4)
        ttk.Entry(login, textvariable=self.password, show="●", width=22).grid(row=0, column=1, padx=4)
        ttk.Button(login, text="登录", command=self.login).grid(row=0, column=2, padx=4)
        ttk.Label(login, text="输入网站管理员邮箱和密码；关闭程序后需重新登录。").grid(row=1, column=0, columnspan=3, sticky="w", pady=5)
        setup = ttk.LabelFrame(body, text="2. 微信测试与家长绑定", padding=10)
        setup.pack(fill="x", pady=10)
        ttk.Button(setup, text="向文件传输助手发送测试", command=self.self_test).grid(row=0, column=0, sticky="w", pady=5)
        self.parent = ttk.Combobox(setup, state="readonly", width=27)
        self.parent.grid(row=1, column=0, pady=5)
        self.contact = tk.StringVar()
        ttk.Entry(setup, textvariable=self.contact, width=28).grid(row=1, column=1, padx=6)
        ttk.Button(setup, text="保存绑定", command=self.bind).grid(row=1, column=2)
        self.consent = tk.BooleanVar(value=False)
        ttk.Checkbutton(setup, text="已获家长同意，并核对当前微信账号与唯一好友备注", variable=self.consent).grid(row=2, column=0, columnspan=3, sticky="w")
        ttk.Label(setup, text="先在微信把该家长备注改为「课前提醒-学员名-家长」，不可重名；绑定仅存本机。").grid(row=3, column=0, columnspan=3, sticky="w", pady=5)
        self.parent.bind("<<ComboboxSelected>>", self.select_parent)
        control = ttk.Frame(body)
        control.pack(fill="x", pady=6)
        ttk.Label(control, text="提前分钟：").pack(side="left")
        self.lead = tk.StringVar(value="60")
        ttk.Spinbox(control, from_=5, to=1440, textvariable=self.lead, width=6).pack(side="left")
        ttk.Button(control, text="预览任务（不发送）", command=self.preview).pack(side="left", padx=8)
        ttk.Button(control, text="开启自动发送", command=self.start).pack(side="left", padx=4)
        ttk.Button(control, text="暂停", command=self.pause).pack(side="left", padx=4)
        ttk.Button(control, text="发送记录", command=self.records).pack(side="left", padx=4)
        self.status = tk.StringVar(value="自动发送关闭。请先登录并完成微信测试。")
        ttk.Label(body, textvariable=self.status, wraplength=700, foreground="#1d4ed8").pack(anchor="w", pady=8)
        self.log = tk.Text(body, height=13, wrap="word", state="disabled", font=("Microsoft YaHei UI", 10))
        self.log.pack(fill="both", expand=True)
        ttk.Label(body, text="程序运行时需保持电脑联网、桌面解锁和微信登录；发送会占用键盘鼠标。\n操作完成不代表家长已收到或已读。未知结果暂停并人工核对，不自动重复发送。", wraplength=700).pack(anchor="w", pady=(10, 0))
        root.protocol("WM_DELETE_WINDOW", self.close)
        root.after(150, self.drain)
        root.after(30000, self.tick)

    def note(self, text):
        self.log.configure(state="normal")
        self.log.insert("end", time.strftime("%H:%M:%S ") + text + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def background(self, action, success=None):
        if self.busy:
            return
        self.busy = True
        def run():
            # 桌面适配器在唯一工作线程内使用 COM；不阻塞界面。
            sys.coinit_flags = 0
            com = ctypes.windll.ole32.CoInitializeEx(None, 0)
            try:
                self.events.put((True, action(), success))
            except Exception as error:
                message = str(error)
                if "讲述人" in message or "微信主界面" in message:
                    message = "当前微信账号或版本未开放可识别的界面，自动化测试未通过。不要反复重试或仅开启讲述人；保持自动通知关闭。"
                self.events.put((False, message, None))
            finally:
                if com in (0, 1):
                    ctypes.windll.ole32.CoUninitialize()
        self.pool.submit(run)

    def drain(self):
        try:
            while True:
                okay, value, callback = self.events.get_nowait()
                self.busy = False
                if okay:
                    if callback:
                        callback(value)
                else:
                    self.pause()
                    self.status.set("操作失败，自动发送已暂停：" + value[:250])
                    self.note(value[:250])
        except queue.Empty:
            pass
        self.root.after(150, self.drain)

    def login(self):
        if self.active or self.busy:
            return
        email, password = self.email.get().strip(), self.password.get()
        self.password.set("")
        def logged(parents):
            self.parents = parents
            self.parent["values"] = [p["name"] + " · " + p["profileId"][-6:] for p in parents]
            self.status.set("网站已连接。请先完成文件传输助手测试。")
        self.background(lambda: self.client.login(email, password), logged)

    def self_test(self):
        if self.active or self.busy:
            return
        if not messagebox.askyesno("本机微信测试", "将使用当前登录的电脑版微信，向文件传输助手发送一条测试消息。请停止使用鼠标键盘，保持桌面解锁。继续？"):
            return
        def test():
            import desktop
            desktop.send("文件传输助手", "【17say 测试】本机微信课前提醒程序测试。此消息只发给文件传输助手。")
        def done(_):
            self.tested = messagebox.askyesno("确认测试", "请查看微信文件传输助手，是否确实收到刚才的测试消息？")
            self.status.set("测试已确认，可以绑定家长。" if self.tested else "测试未确认，自动发送保持关闭。")
        self.background(test, done)

    def select_parent(self, _=None):
        if self.parent.current() < 0:
            return
        profile = self.parents[self.parent.current()]["profileId"]
        binding = self.bindings.get(profile, {})
        self.contact.set(binding.get("contact", ""))
        self.consent.set(False)

    def bind(self):
        if self.active or self.busy:
            messagebox.showinfo("先暂停", "修改绑定前请暂停自动发送。")
            return
        if self.parent.current() < 0 or not self.consent.get():
            messagebox.showinfo("核对绑定", "选择家长，并确认已取得同意、核对微信账号和备注。")
            return
        contact = self.contact.get().strip()
        if not contact.startswith("课前提醒-") or len(contact) < 7:
            messagebox.showinfo("唯一备注", "请使用「课前提醒-学员名-家长」形式的唯一备注。")
            return
        profile = self.parents[self.parent.current()]["profileId"]
        if any(k != profile and b.get("contact") == contact for k, b in self.bindings.items()):
            messagebox.showinfo("备注重复", "该备注已绑定其他家长，请使用不同的唯一备注。")
            return
        self.bindings[profile] = {"contact": contact, "confirmed": True}
        temporary = DATA / "bindings.tmp"
        temporary.write_text(json.dumps(self.bindings, ensure_ascii=False), encoding="utf-8")
        temporary.replace(DATA / "bindings.json")
        self.note("家长绑定已保存。")

    def fetch(self):
        lead = int(self.lead.get())
        if not 5 <= lead <= 1440:
            raise ValueError("提前分钟应为 5～1440")
        return self.client.request("/local-wechat/tasks?lead=" + str(lead))

    def preview(self):
        if self.active:
            return
        # 在主线程读取 Tk 值；后台只处理网络数据。
        try:
            lead = int(self.lead.get())
            if not 5 <= lead <= 1440:
                raise ValueError()
        except ValueError:
            messagebox.showinfo("提前时间", "请输入 5～1440 的整数。")
            return
        def display(value):
            tasks = value["tasks"]
            self.note(f"预览 {len(tasks)} 条课前任务，不发送。")
            for task in tasks[:30]:
                self.note(task["studentName"] + " · " + task["scheduledAt"] +
                          (" · 已绑定" if self.bindings.get(task["profileId"]) else " · 未绑定，跳过"))
        self.background(lambda: self.client.request("/local-wechat/tasks?lead=" + str(lead)), display)

    def records(self):
        def load():
            if self.journal is None:
                self.journal = Journal(DATA / "records.sqlite")
            return self.journal.records()
        def show(rows):
            self.note("最近发送记录：" if rows else "暂无发送记录。")
            labels = {"submitted": "本机已提交，未确认送达", "unknown": "结果未知，需人工核对", "sending": "处理中"}
            for key, state, at in rows:
                self.note(at + " · " + labels.get(state, state) + " · " + key[:8])
        self.background(load, show)

    def start(self):
        if self.busy:
            return
        if not self.client.access or not self.tested or not self.bindings:
            messagebox.showinfo("尚未准备好", "请先登录、确认文件传输助手测试并绑定至少一位家长。")
            return
        try:
            lead = int(self.lead.get())
            if not 5 <= lead <= 1440:
                raise ValueError()
        except ValueError:
            messagebox.showinfo("提前时间", "请输入 5～1440 的整数。")
            return
        if not messagebox.askyesno("开启通知", "确认当前微信账号正确，绑定备注均已核对？将自动向绑定家长发送课前通知。发送期间请不要操作微信。"):
            return
        self.active = True
        self.running_lead = lead
        # 仅在本程序运行时阻止睡眠，暂停/退出即释放，不修改系统电源配置。
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
        self.status.set("自动发送已开启，每 30 秒检查；每次最多发送 1 条。")
        self.poll()

    def pause(self):
        self.active = False
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
        self.status.set("自动发送已暂停；已开始执行的一条消息可能仍会完成。")

    def poll(self):
        if not self.active or self.busy:
            return
        def action():
            if self.journal is None:
                self.journal = Journal(DATA / "records.sqlite")
            tasks = self.client.request("/local-wechat/tasks?lead=" + str(self.running_lead))["tasks"]
            for task in tasks:
                if not self.active:
                    break
                binding = self.bindings.get(task["profileId"])
                if binding and binding.get("confirmed") and not self.journal.seen(task["key"]):
                    if time.monotonic() - self.last_send < 30:
                        break
                    import desktop
                    state = send_task(self.client, self.journal, task, binding, desktop.send)
                    self.last_send = time.monotonic()
                    return "本机提交操作完成（未确认送达）。" if state == "submitted" else "课程已变化，本条已跳过。"
            return "网站检查正常，暂无待发送的已绑定任务。"
        self.background(action, lambda value: (self.status.set(value), self.note(value)))

    def tick(self):
        self.poll()
        self.root.after(30000, self.tick)

    def close(self):
        self.pause()
        if self.busy:
            messagebox.showinfo("正在处理", "请等待当前操作完成后退出。")
            return
        self.pool.shutdown(wait=False)
        self.client.access = self.client.refresh = None
        self.root.destroy()

if __name__ == "__main__":
    ctypes.windll.kernel32.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
    ctypes.windll.kernel32.CreateMutexW.restype = ctypes.c_void_p
    mutex = ctypes.windll.kernel32.CreateMutexW(None, False, "Local\\17sayWechatHelper")
    if ctypes.windll.kernel32.GetLastError() == 183:
        messagebox.showinfo("已在运行", "本机提醒程序已经打开，请使用现有窗口。")
        raise SystemExit(0)
    root = tk.Tk()
    App(root)
    root.mainloop()
