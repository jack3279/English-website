"""本机课前提醒：无密码落盘，SQLite 持久去重，未知结果不自动重发。"""
import json
import sqlite3
from datetime import datetime, timezone
from urllib.request import Request, urlopen
from urllib.error import HTTPError

API = "https://api.17say.org"

class Client:
    def __init__(self):
        self.access = None
        self.refresh = None

    def request(self, path, body=None, retry=True):
        headers = {"Content-Type": "application/json",
                   "User-Agent": "17sayWechatHelper/0.1 (+https://17say.org)"}
        if self.access:
            headers["Authorization"] = "Bearer " + self.access
        request = Request(API + path, headers=headers,
                          data=json.dumps(body).encode() if body is not None else None)
        try:
            with urlopen(request, timeout=15) as response:
                return json.load(response)["data"]
        except HTTPError as error:
            if error.code == 401 and self.refresh and retry and not path.startswith("/auth/"):
                tokens = self.request("/auth/refresh", {"refresh_token": self.refresh}, retry=False)
                self.access, self.refresh = tokens["access_token"], tokens["refresh_token"]
                return self.request(path, body, retry=False)
            try:
                message = json.load(error).get("error", "请求失败")
            except Exception:
                message = "请求失败"
            raise RuntimeError(f"{error.code}：{message}") from None

    def login(self, email, password):
        tokens = self.request("/auth/login", {"email": email, "password": password})
        self.access, self.refresh = tokens["access_token"], tokens["refresh_token"]
        try:
            parents = self.request("/local-wechat/parents")
        except Exception:
            self.access = self.refresh = None
            raise
        return parents

class Journal:
    def __init__(self, path):
        self.db = sqlite3.connect(path)
        self.db.execute("CREATE TABLE IF NOT EXISTS notices (key TEXT PRIMARY KEY, state TEXT, at TEXT)")
        # 退出或崩溃时无法确认结果，禁止自动重发。
        self.db.execute("UPDATE notices SET state='unknown' WHERE state='sending'")
        self.db.commit()

    def seen(self, key):
        return self.db.execute("SELECT state FROM notices WHERE key=?", (key,)).fetchone() is not None

    def claim(self, key):
        try:
            self.db.execute("INSERT INTO notices VALUES (?, 'sending', ?)",
                            (key, datetime.now(timezone.utc).isoformat()))
            self.db.commit()
            return True
        except sqlite3.IntegrityError:
            return False

    def finish(self, key, state):
        self.db.execute("UPDATE notices SET state=? WHERE key=?", (state, key))
        self.db.commit()

    def records(self):
        return self.db.execute("SELECT key,state,at FROM notices ORDER BY at DESC LIMIT 50").fetchall()

def send_task(client, journal, task, binding, sender):
    if not binding or not binding.get("confirmed") or journal.seen(task["key"]):
        return "skipped"
    fresh = client.request("/local-wechat/validate", {
        "lessonId": task["lessonId"], "parentId": task["parentId"], "key": task["key"],
    })
    if not fresh.get("valid"):
        return "cancelled"
    if not journal.claim(task["key"]):
        return "skipped"
    try:
        sender(binding["contact"], fresh["task"]["message"])
    except Exception:
        journal.finish(task["key"], "unknown")
        report(client, task, "unknown")
        raise RuntimeError("微信操作未能确认完成，请人工检查聊天记录；本条不会自动重发") from None
    # 仅代表电脑版操作完成，不等于家长已收到或已读。
    journal.finish(task["key"], "submitted")
    report(client, task, "submitted")
    return "submitted"

def report(client, task, state):
    try:
        client.request("/local-wechat/result", {
            "lessonId": task["lessonId"], "key": task["key"], "state": state,
        })
    except Exception:
        # 回报故障不能撤销本机去重记录或触发重复发送。
        pass
