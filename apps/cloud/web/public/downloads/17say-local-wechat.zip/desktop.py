"""由用户启动的 Windows 微信发送适配器；导入本模块不会读取或操作微信。"""
import ctypes
import time

def send(contact, message):
    # 锁屏/非交互桌面时失败，不向后台窗口盲发。
    ctypes.windll.user32.OpenInputDesktop.restype = ctypes.c_void_p
    ctypes.windll.user32.CloseDesktop.argtypes = [ctypes.c_void_p]
    desktop = ctypes.windll.user32.OpenInputDesktop(0, False, 0x0100)
    if not desktop:
        raise RuntimeError("桌面已锁定，请解锁后操作")
    ctypes.windll.user32.CloseDesktop(desktop)
    from pyweixin import Navigator
    from pyweixin.Uielements import Texts, Edits
    import pyautogui
    window = Navigator.open_dialog_window(friend=contact, search_pages=0, is_maximize=False)
    title = window.child_window(**Texts.CurrentChatNameText)
    if not title.exists(timeout=2) or title.window_text() != contact:
        raise RuntimeError("聊天标题与绑定备注不完全一致，已停止发送")
    if window.child_window(**Texts.GroupLabelText).exists(timeout=0.3):
        raise RuntimeError("当前是群聊，已停止发送；只允许绑定家长好友")
    editor = window.child_window(**Edits.CurrentChatEdit)
    if not editor.exists(timeout=2):
        raise RuntimeError("没有找到聊天输入框")
    # 保留尚未发送的手工草稿，不覆盖它。
    if editor.get_value().strip():
        raise RuntimeError("聊天中有未发送草稿，已停止发送")
    editor.click_input()
    editor.set_text(message)
    time.sleep(0.3)
    if title.window_text() != contact:
        raise RuntimeError("聊天窗口已改变，已停止发送")
    ctypes.windll.user32.GetForegroundWindow.restype = ctypes.c_void_p
    if ctypes.windll.user32.GetForegroundWindow() != window.handle:
        raise RuntimeError("微信不在前台，已停止发送")
    pyautogui.FAILSAFE = True
    pyautogui.hotkey("alt", "s")

