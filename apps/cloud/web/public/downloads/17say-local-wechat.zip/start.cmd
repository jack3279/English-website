@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
  echo 请先运行 install.cmd 安装运行环境。
  pause
  exit /b 1
)
start "" ".venv\Scripts\pythonw.exe" "app.py"
